﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using System.Collections.Generic;
using XnaCards;

namespace FiveCardDraw
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        //graphics object
        GraphicsDeviceManager graphics;

        //spritebatch object
        SpriteBatch spriteBatch;

        //deck
        Deck deck;

        //spritefont
        SpriteFont messageFont;

        //game state tracking
        static GameState currentState = GameState.InitialDeal;

        //resolution
        const int WINDOW_WIDTH = 800;
        const int WINDOW_HEIGHT = 600;

        //lists
        List<Card> dealerHand = new List<Card>();
        List<Card> playerHand = new List<Card>();
        List<Message> messages = new List<Message>();
        List<MenuButton> menuButtons = new List<MenuButton>();
        List<Vector2> cardLocations = new List<Vector2>();

        //message prefixes
        string SCORE_MESSAGE_PREFIX = "Score: ";
        string FEEDBACK_MESSAGE_PREFIX = " ";

        //message location constants
        const int PLAYER_MESSAGE_HOR_OFFSET = WINDOW_WIDTH / 2;
        const int PLAYER_SCORE_MESSAGE_VER_OFFSET = 15;
        const int PLAYER_FEEDBACK_MESSAGE_VER_OFFSET = 45;
        const int GAME_FEEDBACK_MESSAGE_HOR_OFFSET = WINDOW_WIDTH / 2;
        const int GAME_FEEDBACK_MESSAGE_VER_OFFSET = WINDOW_HEIGHT / 2;

        //message index
        const int MNUM_PLAYER_SCORE = 0;
        const int MNUM_PLAYER_FEEDBACK = 1;
        const int MNUM_DEALER_SCORE = 2;
        const int MNUM_DEALER_FEEDBACK = 3;
        const int MNUM_GAME_FEEDBACK = 4;

        //message placement (constants)
        Vector2 MLOC_PLAYER_SCORE = new Vector2(PLAYER_MESSAGE_HOR_OFFSET, PLAYER_SCORE_MESSAGE_VER_OFFSET);
        Vector2 MLOC_PLAYER_FEEDBACK = new Vector2(PLAYER_MESSAGE_HOR_OFFSET, PLAYER_FEEDBACK_MESSAGE_VER_OFFSET);
        Vector2 MLOC_DEALER_SCORE = new Vector2(PLAYER_MESSAGE_HOR_OFFSET, WINDOW_HEIGHT - PLAYER_SCORE_MESSAGE_VER_OFFSET);
        Vector2 MLOC_DEALER_FEEDBACK = new Vector2(PLAYER_MESSAGE_HOR_OFFSET, WINDOW_HEIGHT - PLAYER_FEEDBACK_MESSAGE_VER_OFFSET);
        Vector2 MLOC_GAME_FEEDBACK = new Vector2(GAME_FEEDBACK_MESSAGE_HOR_OFFSET, GAME_FEEDBACK_MESSAGE_VER_OFFSET);

        //player scoring
        long playerHandScore = 0;
        long dealerHandScore = 0;
        long playerTotalScore = 0;
        long dealerTotalScore = 0;
        string playerHandName = "";
        string dealerHandName = "";

        //dealing timer
        int timeSinceDeal = 301;
        int timeUntilDeal = 300;
        bool allowDealing = false;
        bool redealtPlayer0 = false;
        bool redealtPlayer1 = false;
        bool redealtPlayer2 = false;
        bool redealtPlayer3 = false;
        bool redealtPlayer4 = false;
        bool redealtDealer0 = false;
        bool redealtDealer1 = false;
        bool redealtDealer2 = false;
        bool redealtDealer3 = false;
        bool redealtDealer4 = false;

        //menu button sprites
        Texture2D discardButtonSprite;
        Texture2D keepButtonSprite;
        Texture2D doneButtonSprite;

        //menu button vectors
        Vector2 discard0ButtonLocation;
        Vector2 discard1ButtonLocation;
        Vector2 discard2ButtonLocation;
        Vector2 discard3ButtonLocation;
        Vector2 discard4ButtonLocation;
        Vector2 keep0ButtonLocation;
        Vector2 keep1ButtonLocation;
        Vector2 keep2ButtonLocation;
        Vector2 keep3ButtonLocation;
        Vector2 keep4ButtonLocation;
        Vector2 doneButtonLocation;

        //menu buttons
        MenuButton discard0Button;
        MenuButton discard1Button;
        MenuButton discard2Button;
        MenuButton discard3Button;
        MenuButton discard4Button;
        MenuButton keep0Button;
        MenuButton keep1Button;
        MenuButton keep2Button;
        MenuButton keep3Button;
        MenuButton keep4Button;
        MenuButton doneButton;

        //menu button misc
        public static bool buttonConfigChanged = true;

        //discard switches
        public static bool discarding0 = false;
        public static bool discarding1 = false;
        public static bool discarding2 = false;
        public static bool discarding3 = false;
        public static bool discarding4 = false;

        //discard switches
        bool playerDiscarding0 = false;
        bool playerDiscarding1 = false;
        bool playerDiscarding2 = false;
        bool playerDiscarding3 = false;
        bool playerDiscarding4 = false;
        bool dealerDiscarding0 = false;
        bool dealerDiscarding1 = false;
        bool dealerDiscarding2 = false;
        bool dealerDiscarding3 = false;
        bool dealerDiscarding4 = false;

        //menu button constants
        int HORIZONTAL_MENU_BUTTON_OFFSET = 210;
        int HORIZONTAL_MENU_BUTTON_SPACING = 95;
        int VERTICAL_MENU_BUTTON_SPACING = 241;

        //sound effects
        SoundEffect deal;
        SoundEffect shuffle;

        //right click support (for restarting game)
        bool rightClickStarted = false;
        bool rightButtonReleased = false;

        public Game1()
        {
            //instanciate graphics object
            graphics = new GraphicsDeviceManager(this);

            //set content default dir
            Content.RootDirectory = "Content";

            //set resolution
            graphics.PreferredBackBufferWidth = WINDOW_WIDTH;
            graphics.PreferredBackBufferHeight = WINDOW_HEIGHT;

            //show mouse
            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //load sprite font
            messageFont = Content.Load<SpriteFont>(@"spritefont\Arial24");

            //load button sprites
            discardButtonSprite = Content.Load<Texture2D>(@"graphics\discard");
            keepButtonSprite = Content.Load<Texture2D>(@"graphics\keep");
            doneButtonSprite = Content.Load<Texture2D>(@"graphics\done");

            //load soundeffects
            deal = Content.Load<SoundEffect>(@"sounds/deal");
            shuffle = Content.Load<SoundEffect>(@"sounds/shuffle");

            //button locations
            discard0ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET, VERTICAL_MENU_BUTTON_SPACING);
            discard1ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + HORIZONTAL_MENU_BUTTON_SPACING, VERTICAL_MENU_BUTTON_SPACING);
            discard2ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 2), VERTICAL_MENU_BUTTON_SPACING);
            discard3ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 3), VERTICAL_MENU_BUTTON_SPACING);
            discard4ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 4), VERTICAL_MENU_BUTTON_SPACING);
            keep0ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET, VERTICAL_MENU_BUTTON_SPACING);
            keep1ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + HORIZONTAL_MENU_BUTTON_SPACING, VERTICAL_MENU_BUTTON_SPACING);
            keep2ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 2), VERTICAL_MENU_BUTTON_SPACING);
            keep3ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 3), VERTICAL_MENU_BUTTON_SPACING);
            keep4ButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 4), VERTICAL_MENU_BUTTON_SPACING);
            doneButtonLocation = new Vector2(HORIZONTAL_MENU_BUTTON_OFFSET + (HORIZONTAL_MENU_BUTTON_SPACING * 5), VERTICAL_MENU_BUTTON_SPACING);

            //create discard buttons
            discard0Button = new MenuButton(discardButtonSprite, discard0ButtonLocation, 0);
            discard1Button = new MenuButton(discardButtonSprite, discard1ButtonLocation, 1);
            discard2Button = new MenuButton(discardButtonSprite, discard2ButtonLocation, 2);
            discard3Button = new MenuButton(discardButtonSprite, discard3ButtonLocation, 3);
            discard4Button = new MenuButton(discardButtonSprite, discard4ButtonLocation, 4);

            //create keep buttons
            keep0Button = new MenuButton(keepButtonSprite, keep0ButtonLocation, 0);
            keep1Button = new MenuButton(keepButtonSprite, keep1ButtonLocation, 1);
            keep2Button = new MenuButton(keepButtonSprite, keep2ButtonLocation, 2);
            keep3Button = new MenuButton(keepButtonSprite, keep3ButtonLocation, 3);
            keep4Button = new MenuButton(keepButtonSprite, keep4ButtonLocation, 4);

            //create keep button
            doneButton = new MenuButton(doneButtonSprite, doneButtonLocation, 5);

            //start a new game
            startNewGame();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent() { }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            //exit code
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape)) { Exit(); }

            //get mouse state
            MouseState mouseState = Mouse.GetState();

            //right click support
            if (currentState == GameState.DisplayHandResults)
            {
                if (mouseState.RightButton == ButtonState.Pressed && rightButtonReleased)
                {
                    rightClickStarted = true;
                    rightButtonReleased = false;
                }
                else if (mouseState.RightButton == ButtonState.Released)
                {
                    rightButtonReleased = true;
                    if (rightClickStarted)
                    {
                        rightClickStarted = false;
                        startNewGame();
                        ChangeState(GameState.InitialDeal);
                    }
                }
            }

            //finite state switch
            switch (currentState)
            {
                case GameState.InitialDeal:
                    {
                        //if all cards have not yet been dealt
                        if (playerHand.Count + dealerHand.Count < 10)
                        {
                            //update dealing timer
                            timeSinceDeal += gameTime.ElapsedGameTime.Milliseconds;

                            //check to see if the dealing timer went off
                            if (timeSinceDeal > timeUntilDeal)
                            {
                                //if the dealer has less cards than the player
                                if (dealerHand.Count < playerHand.Count)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                }
                                //else the dealer has the same amount of cards as player
                                else
                                {
                                    //deal to the player
                                    dealACard("Player");
                                }
                                //reset dealing timer
                                timeSinceDeal = 0;
                            }
                        }
                        //else all cards were dealt
                        else
                        {
                            //change the gamestate
                            currentState = GameState.ScoreInitialHands;
                        }

                        //break
                        break;
                    }
                case GameState.ScoreInitialHands:
                    {
                        //score players hand
                        updatePlayerHandMessage();
                        scoreHand("player", playerHand, MNUM_PLAYER_FEEDBACK);

                        //score dealers hand
                        scoreHand("dealer", dealerHand, MNUM_DEALER_FEEDBACK);

                        //change the gamestate
                        currentState = GameState.WaitingForPlayerToDiscard;

                        //break
                        break;
                    }
                case GameState.WaitingForPlayerToDiscard:
                    {
                        if (buttonConfigChanged == true)
                        {
                            menuButtons.Clear();
                            if (discarding0 == false) { menuButtons.Add(discard0Button); } else { menuButtons.Add(keep0Button); }
                            if (discarding1 == false) { menuButtons.Add(discard1Button); } else { menuButtons.Add(keep1Button); }
                            if (discarding2 == false) { menuButtons.Add(discard2Button); } else { menuButtons.Add(keep2Button); }
                            if (discarding3 == false) { menuButtons.Add(discard3Button); } else { menuButtons.Add(keep3Button); }
                            if (discarding4 == false) { menuButtons.Add(discard4Button); } else { menuButtons.Add(keep4Button); }
                            menuButtons.Add(doneButton);
                            buttonConfigChanged = false;
                        }
                        updateGameFeedbackMessage("Select your discards.");
                        //break
                        break;
                    }

                case GameState.DiscardPlayersCards:
                    {
                        updateGameFeedbackMessage("Discarding");

                        if (discarding4 == true)
                        {
                            playerHand.RemoveAt(4);
                            playerDiscarding4 = true;
                        }
                        if (discarding3 == true)
                        {
                            playerHand.RemoveAt(3);
                            playerDiscarding3 = true;
                        }
                        if (discarding2 == true)
                        {
                            playerHand.RemoveAt(2);
                            playerDiscarding2 = true;
                        }
                        if (discarding1 == true)
                        {
                            playerHand.RemoveAt(1);
                            playerDiscarding1 = true;
                        }
                        if (discarding0 == true)
                        {
                            playerHand.RemoveAt(0);
                            playerDiscarding0 = true;
                        }

                        currentState = GameState.WaitingForDealerToDiscard;

                        //break
                        break;
                    }
                case GameState.WaitingForDealerToDiscard:
                    {
                        updateGameFeedbackMessage("Thinking...");

                        if (dealerDiscarding4 == true)
                        {
                            dealerHand.RemoveAt(4);
                        }
                        if (dealerDiscarding3 == true)
                        {
                            dealerHand.RemoveAt(3);
                        }
                        if (dealerDiscarding2 == true)
                        {
                            dealerHand.RemoveAt(2);
                        }
                        if (dealerDiscarding1 == true)
                        {
                            dealerHand.RemoveAt(1);
                        }
                        if (dealerDiscarding0 == true)
                        {
                            dealerHand.RemoveAt(0);
                        }

                        currentState = GameState.FinalDeal;

                        //create card location list
                        cardLocations.Clear();

                        //dealt card location list
                        int y = 172;
                        for (int x = 210; x <= 590; x += 95)
                        {
                            cardLocations.Add(new Vector2(x, y));
                        }
                        y = 172;
                        for (int x = 210; x <= 590; x += 95)
                        {
                            cardLocations.Add(new Vector2(x, WINDOW_HEIGHT - y));
                        }

                        //break
                        break;
                    }
                case GameState.FinalDeal:
                    {
                        //update dealing timer
                        timeSinceDeal += gameTime.ElapsedGameTime.Milliseconds;

                        //check to see if the dealing timer went off
                        if (timeSinceDeal > timeUntilDeal)
                        {
                            //permit a deal
                            allowDealing = true;

                            //if the player discarded their card in slot 0
                            if (allowDealing == true && redealtPlayer0 == false)
                            {
                                redealtPlayer0 = true;
                                if (playerDiscarding0 == true)
                                {
                                    //deal to the player
                                    dealACard("Player");
                                    playerDiscarding0 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the player discarded their card in slot 1
                            if (allowDealing == true && redealtPlayer1 == false)
                            {
                                redealtPlayer1 = true;
                                if (playerDiscarding1 == true)
                                {
                                    //deal to the player
                                    dealACard("Player");
                                    playerDiscarding1 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the player discarded their card in slot 2
                            if (allowDealing == true && redealtPlayer2 == false)
                            {
                                redealtPlayer2 = true;
                                if (playerDiscarding2 == true)
                                {
                                    //deal to the player
                                    dealACard("Player");
                                    playerDiscarding2 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the player discarded their card in slot 3
                            if (allowDealing == true && redealtPlayer3 == false)
                            {
                                redealtPlayer3 = true;
                                if (playerDiscarding3 == true)
                                {
                                    //deal to the player
                                    dealACard("Player");
                                    playerDiscarding3 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the player discarded their card in slot 4
                            if (allowDealing == true && redealtPlayer4 == false)
                            {
                                redealtPlayer4 = true;
                                if (playerDiscarding4 == true)
                                {
                                    //deal to the player
                                    dealACard("Player");
                                    playerDiscarding4 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the dealer discarded their card in slot 0
                            if (allowDealing == true && redealtDealer0 == false)
                            {
                                redealtDealer0 = true;
                                if (dealerDiscarding0 == true)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                    dealerDiscarding0 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the dealer discarded their card in slot 1
                            if (allowDealing == true && redealtDealer1 == false)
                            {
                                redealtDealer1 = true;
                                if (dealerDiscarding1 == true)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                    dealerDiscarding1 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the dealer discarded their card in slot 2
                            if (allowDealing == true && redealtDealer2 == false)
                            {
                                redealtDealer2 = true;
                                if (dealerDiscarding2 == true)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                    dealerDiscarding2 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the dealer discarded their card in slot 3
                            if (allowDealing == true && redealtDealer3 == false)
                            {
                                redealtDealer3 = true;
                                if (dealerDiscarding3 == true)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                    dealerDiscarding3 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                            //if the dealer discarded their card in slot 4
                            if (allowDealing == true && redealtDealer4 == false)
                            {
                                redealtDealer4 = true;
                                if (dealerDiscarding4 == true)
                                {
                                    //deal to the dealer
                                    dealACard("Dealer");
                                    dealerDiscarding4 = false;
                                    allowDealing = false;

                                    //reset dealing timer
                                    timeSinceDeal = 0;
                                }
                                else
                                {
                                    //remove the vector from the list since its not needed
                                    cardLocations.RemoveAt(0);
                                }
                            }

                        }

                        if (playerHand.Count + dealerHand.Count == 10) { currentState = GameState.ScoreFinalHands; }

                        //break
                        break;
                    }
                case GameState.ScoreFinalHands:
                    {
                        //score players hand
                        updatePlayerHandMessage();
                        scoreHand("player", playerHand, MNUM_PLAYER_FEEDBACK);

                        //score dealers hand
                        updateDealerHandMessage();
                        scoreHand("dealer", dealerHand, MNUM_DEALER_FEEDBACK);

                        //change the gamestate
                        currentState = GameState.DisplayHandResults;

                        //break
                        break;
                    }
                case GameState.DisplayHandResults:
                    {
                        if (dealerHand[0].FaceUp == false)
                        {
                            dealerHand[0].FlipOver();
                            dealerHand[1].FlipOver();
                            dealerHand[2].FlipOver();
                            dealerHand[3].FlipOver();
                            dealerHand[4].FlipOver();

                            //update the feedback and assign points to winner
                            if (playerHandScore > dealerHandScore)
                            {
                                updateGameFeedbackMessage("Player Wins! Right click to play again.");
                                if (playerHandName == "Royal Flush") { playerTotalScore = playerTotalScore + 800; }
                                else if (playerHandName == "Straight Flush") { playerTotalScore = playerTotalScore + 50; }
                                else if (playerHandName == "Four Of A Kind") { playerTotalScore = playerTotalScore + 40; }
                                else if (playerHandName == "Full House") { playerTotalScore = playerTotalScore + 10; }
                                else if (playerHandName == "Flush") { playerTotalScore = playerTotalScore + 7; }
                                else if (playerHandName == "Straight") { playerTotalScore = playerTotalScore + 5; }
                                else if (playerHandName == "Three Of A Kind") { playerTotalScore = playerTotalScore + 4; }
                                else if (playerHandName == "Two Pair") { playerTotalScore = playerTotalScore + 3; }
                                else if (playerHandName == "One Pair") { playerTotalScore = playerTotalScore + 2; }
                                else if (playerHandName == "High Card") { playerTotalScore = playerTotalScore + 1; }
                                updatePlayerScoreMessage();
                                updatePlayerHandMessage();
                            }
                            else if (dealerHandScore > playerHandScore)
                            {
                                updateGameFeedbackMessage("Dealer Wins! Right click to play again.");
                                if (dealerHandName == "Royal Flush") { dealerTotalScore = dealerTotalScore + 800; }
                                else if (dealerHandName == "Straight Flush") { dealerTotalScore = dealerTotalScore + 50; }
                                else if (dealerHandName == "Four Of A Kind") { dealerTotalScore = dealerTotalScore + 40; }
                                else if (dealerHandName == "Full House") { dealerTotalScore = dealerTotalScore + 10; }
                                else if (dealerHandName == "Flush") { dealerTotalScore = dealerTotalScore + 7; }
                                else if (dealerHandName == "Straight") { dealerTotalScore = dealerTotalScore + 5; }
                                else if (dealerHandName == "Three Of A Kind") { dealerTotalScore = dealerTotalScore + 4; }
                                else if (dealerHandName == "Two Pair") { dealerTotalScore = dealerTotalScore + 3; }
                                else if (dealerHandName == "One Pair") { dealerTotalScore = dealerTotalScore + 2; }
                                else if (dealerHandName == "High Card") { dealerTotalScore = dealerTotalScore + 1; }
                                updateDealerScoreMessage();
                                updateDealerHandMessage();
                            }
                            else { updateGameFeedbackMessage("Its a push! Right click to play again."); }
                        }

                        //break
                        break;
                    }
            }

            //adjust menubuttons as required
            if (currentState == GameState.WaitingForPlayerToDiscard)
            {
                //update the menubuttons
                foreach (MenuButton menubutton in menuButtons) { menubutton.Update(mouseState); }
            }
            else
            {
                //clear the menubuttons
                menuButtons.Clear();
            }

            //update the game
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            //set beckground color
            GraphicsDevice.Clear(Color.DarkGreen);

            //begin spritebatch
            spriteBatch.Begin();

            //draw playerhand
            foreach (Card card in playerHand) { card.Draw(spriteBatch); }

            //draw dealerhand
            foreach (Card card in dealerHand) { card.Draw(spriteBatch); }

            //draw messages
            foreach (Message message in messages) { message.Draw(spriteBatch); }

            //draw menubuttons
            foreach (MenuButton menuButton in menuButtons) { menuButton.Draw(spriteBatch); }

            //end spritebatch
            spriteBatch.End();

            //draw the game
            base.Draw(gameTime);
        }

        #region Public Methods

        /// <summary>
        /// Resets the variables for another game
        /// </summary>
        public void startNewGame()
        {
            //reset variables
            discarding0 = false;
            discarding1 = false;
            discarding2 = false;
            discarding3 = false;
            discarding4 = false;
            playerDiscarding0 = false;
            playerDiscarding1 = false;
            playerDiscarding2 = false;
            playerDiscarding3 = false;
            playerDiscarding4 = false;
            dealerDiscarding0 = false;
            dealerDiscarding1 = false;
            dealerDiscarding2 = false;
            dealerDiscarding3 = false;
            dealerDiscarding4 = false;
            buttonConfigChanged = true;
            timeSinceDeal = 0;
            timeUntilDeal = 300;
            playerHandScore = 0;
            dealerHandScore = 0;
            playerHandName = "";
            dealerHandName = "";
            allowDealing = false;
            redealtPlayer0 = false;
            redealtPlayer1 = false;
            redealtPlayer2 = false;
            redealtPlayer3 = false;
            redealtPlayer4 = false;
            redealtDealer0 = false;
            redealtDealer1 = false;
            redealtDealer2 = false;
            redealtDealer3 = false;
            redealtDealer4 = false;

            //clear the players hand
            playerHand.Clear();

            //clear the dealers hand
            dealerHand.Clear();

            //clear and create card location list
            cardLocations.Clear();
            createCardLocationsList();

            //reset all messages
            resetAllMessages();

            //create dealers deck
            createANewDealersDeck();
        }

        /// <summary>
        /// Creates a new arrangement for dealt cards
        /// </summary>
        public void createCardLocationsList()
        {
            //dealt card location list
            int y = 172;
            for (int x = 210; x <= 590; x += 95)
            {
                cardLocations.Add(new Vector2(x, y));
                cardLocations.Add(new Vector2(x, WINDOW_HEIGHT - y));
            }
        }


        /// <summary>
        /// Creates a new deck for the dealer
        /// </summary>
        public void createANewDealersDeck()
        {
            //creates a deck, shuffles it, and notifies the user.
            deck = new Deck(Content, 0, 0);
            deck.Shuffle();
            shuffle.Play(0.05f, -0.05f, 0);
            updateGameFeedbackMessage("Shuffling the deck");

            //stacks the players and dealers hands (used for testing)
            //playerHand.Add(new Card(Content, XnaCards.Rank.Three, XnaCards.Suit.Hearts, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //playerHand[0].FlipOver();
            //dealerHand.Add(new Card(Content, XnaCards.Rank.Two, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //dealerHand[0].FlipOver();
            //playerHand.Add(new Card(Content, XnaCards.Rank.Queen, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //playerHand[1].FlipOver();
            //dealerHand.Add(new Card(Content, XnaCards.Rank.Five, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //dealerHand[1].FlipOver();
            //playerHand.Add(new Card(Content, XnaCards.Rank.Three, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //playerHand[2].FlipOver();
            //dealerHand.Add(new Card(Content, XnaCards.Rank.Two, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //dealerHand[2].FlipOver();
            //playerHand.Add(new Card(Content, XnaCards.Rank.Jack, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //playerHand[3].FlipOver();
            //dealerHand.Add(new Card(Content, XnaCards.Rank.Jack, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //dealerHand[3].FlipOver();
            //playerHand.Add(new Card(Content, XnaCards.Rank.Three, XnaCards.Suit.Clubs, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //playerHand[4].FlipOver();
            //dealerHand.Add(new Card(Content, XnaCards.Rank.Five, XnaCards.Suit.Diamonds, (int)cardLocations[0].X, (int)cardLocations[0].Y));
            //cardLocations.RemoveAt(0);
            //dealerHand[4].FlipOver();
        }

        /// <summary>
        /// Deals the a card
        /// </summary>
        public void dealACard(string Target)
        {
            if (Target == "Dealer")
            {
                //dealt card goes to dealer
                if (deck.Count < 1) { createANewDealersDeck(); }
                dealerHand.Add(deck.TakeTopCard());
                //dealerHand[dealerHand.Count - 1].FlipOver();
                dealerHand[dealerHand.Count - 1].X = (int)(cardLocations[0].X);
                dealerHand[dealerHand.Count - 1].Y = (int)cardLocations[0].Y;
                cardLocations.RemoveAt(0);
                updateGameFeedbackMessage("Dealing a card to dealer");
            }
            else
            {
                //dealt card goes to player
                if (deck.Count < 1) { createANewDealersDeck(); }
                playerHand.Add(deck.TakeTopCard());
                playerHand[playerHand.Count - 1].FlipOver();
                playerHand[playerHand.Count - 1].X = (int)cardLocations[0].X;
                playerHand[playerHand.Count - 1].Y = (int)cardLocations[0].Y;
                cardLocations.RemoveAt(0);
                updateGameFeedbackMessage("Dealing a card to player");
            }
            deal.Play(0.05f, -0.05f, 0);
        }


        /// <summary>
        /// Changes the state of the game
        /// </summary>
        /// <param name="newState">the new game state</param>
        public static void ChangeState(GameState newState) { currentState = newState; }


        /// <summary>
        /// compiles a new feedback message
        /// </summary>
        public void updateGameFeedbackMessage(string feedback) { messages[MNUM_GAME_FEEDBACK].Text = feedback; }


        /// <summary>
        /// compiles a new player score message
        /// </summary>
        public void updatePlayerScoreMessage() { messages[MNUM_PLAYER_SCORE].Text = SCORE_MESSAGE_PREFIX + playerTotalScore; }


        /// <summary>
        /// compiles a new dealer score message
        /// </summary>
        public void updateDealerScoreMessage() { messages[MNUM_DEALER_SCORE].Text = SCORE_MESSAGE_PREFIX + dealerTotalScore; }


        /// <summary>
        /// compiles a new player hand message
        /// </summary>
        public void updatePlayerHandMessage() { messages[MNUM_PLAYER_FEEDBACK].Text = playerHandName; }


        /// <summary>
        /// compiles a new dealer hand message
        /// </summary>
        public void updateDealerHandMessage() { messages[MNUM_DEALER_FEEDBACK].Text = dealerHandName; }


        /// <summary>
        /// Creates (6) empty message list items
        /// </summary>
        public void resetAllMessages()
        {
            messages.Clear();
            messages.Add(new Message(SCORE_MESSAGE_PREFIX + playerTotalScore, messageFont, MLOC_PLAYER_SCORE));
            messages.Add(new Message(FEEDBACK_MESSAGE_PREFIX, messageFont, MLOC_PLAYER_FEEDBACK));
            messages.Add(new Message(SCORE_MESSAGE_PREFIX + dealerTotalScore, messageFont, MLOC_DEALER_SCORE));
            messages.Add(new Message(FEEDBACK_MESSAGE_PREFIX, messageFont, MLOC_DEALER_FEEDBACK));
            messages.Add(new Message("Initializing", messageFont, MLOC_GAME_FEEDBACK));
        }


        /// <summary>
        /// Scores the hand for both players and determines dealers discards
        /// My god... Its full of checks...
        /// </summary>
        public void scoreHand(string target, List<Card> targetHand, int targetFeedbackSlot)
        {
            // ========================================
            // ========================================
            // determine the result of the targets hand
            // ========================================
            // ========================================

            //scoring tools
            bool hasHighCard = true;
            bool hasFlush = true;
            bool hasStraight = true;
            bool hasOnePair = true;
            bool hasTwoPair = true;
            bool hasThreeOfAKind = true;
            bool hasFullHouse = true;
            bool hasFourOfAKind = true;
            int valFourOfAKindQuad = 0;
            int valFourOfAKindSingle = 0;
            int valFullHouseTriple = 0;
            int valFullHouseDouble = 0;
            int valThreeOfAKindTrip = 0;
            int valThreeOfAKindSingle1 = 0;
            int valThreeOfAKindSingle2 = 0;
            int valFlush = 0;
            int valStraight = 0;
            long valStraightFlush = 0;
            int valTwoPairFirst = 0;
            int valTwoPairSecond = 0;
            int valTwoPairSingle = 0;
            int valOnePairPair = 0;
            int valOnePairSingle1 = 0;
            int valOnePairSingle2 = 0;
            int valOnePairSingle3 = 0;
            int valHighCard = 0;
            List<int> handRanks = new List<int>();
            HashSet<int> handPairs = new HashSet<int>();
            List<int> dealer4sd0 = new List<int>();
            List<int> dealer4sd1 = new List<int>();
            List<int> dealer4sd2 = new List<int>();
            List<int> dealer4sd3 = new List<int>();
            List<int> dealer4sd4 = new List<int>();
            int dealerKeeping1 = 0;
            int dealerKeeping2 = 0;
            long handScore = 0;
            string handName = "None";

            //create temporary scoring lists
            for (int i = 0; i < 5; i++)
            {
                handRanks.Add(GetCardRankValue(targetHand[i]));
                handPairs.Add(GetCardRankValue(targetHand[i]));
            }
            handRanks.Sort(); 

            //check for flush
            for (int i = 0; i < 4; i++)
            {
                for (int j = i + 1; j < 5; j++)
                {
                    if (targetHand[i].Suit != targetHand[j].Suit) { hasFlush = false; }
                }
            }

            //check for straight
            for (int i = 0; i < 4; i++)
            {
                if (handRanks[i + 1] - handRanks[i] != 1) { hasStraight = false; }
            }
            //permit an ace to be counted as 1
            if (handRanks[0] == 2 && handRanks[1] == 3 && handRanks[2] == 4 && handRanks[3] == 5 && handRanks[4] == 14) { hasStraight = true; }

            //check pairs
            if (handPairs.Count == 5)
            {
                hasOnePair = false;
                hasTwoPair = false;
                hasThreeOfAKind = false;
                hasFullHouse = false;
                hasFourOfAKind = false;
                if (hasStraight == false && hasFlush == false) { hasHighCard = true; }
            }
            else if (handPairs.Count == 4)
            {
                hasOnePair = true;
                hasTwoPair = false;
                hasThreeOfAKind = false;
                hasFullHouse = false;
                hasFourOfAKind = false;
                for (int i = 0; i < 4; i++)
                {
                    for (int j = i + 1; i < 5; i++)
                    {
                        if (handRanks[i] == handRanks[j]) { valOnePairPair = handRanks[i]; }
                    }
                }
                for (int k = 0; k < 5; k++)
                {
                    if (handRanks[k] != valOnePairPair && valOnePairSingle3 == 0) { valOnePairSingle3 = handRanks[k]; }
                    else if (handRanks[k] != valOnePairPair && valOnePairSingle2 == 0) { valOnePairSingle2 = handRanks[k]; }
                    else if (handRanks[k] != valOnePairPair && valOnePairSingle1 == 0) { valOnePairSingle1 = handRanks[k]; }
                }
            }
            else if (handPairs.Count == 3)
            {
                hasOnePair = false;
                hasTwoPair = false;
                hasThreeOfAKind = false;
                hasFullHouse = false;
                hasFourOfAKind = false;

                //determine two pair or three of a kind
                for (int i = 0; i < 3; i++)
                {
                    for (int j = i + 1; j < 4; j++)
                    {
                        for (int k = i + 2; k < 5; k++)
                        {
                            if (handRanks[i] == handRanks[j] && handRanks[i] == handRanks[k])
                            {
                                hasThreeOfAKind = true;
                                valThreeOfAKindTrip = handRanks[i];
                                for (int l = 0; l < 5; l++)
                                {
                                    if (handRanks[l] != valThreeOfAKindTrip)
                                    {
                                        if (valThreeOfAKindSingle1 == 0)
                                        {
                                            valThreeOfAKindSingle1 = handRanks[l];
                                        }
                                        else
                                        {
                                            valThreeOfAKindSingle2 = handRanks[l];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (hasThreeOfAKind == false)
                {
                    hasTwoPair = true;
                    for (int m = 0; m < 4; m++)
                    {
                        for (int n = m + 1; n < 5; n++)
                        {
                            if (handRanks[m] == handRanks[n])
                            {
                                if (valTwoPairSecond == 0)
                                {
                                    valTwoPairSecond = handRanks[n];
                                }
                                else
                                {
                                    valTwoPairFirst = handRanks[n];
                                }
                            }
                        }
                    }
                    for (int o = 0; o < 5; o++)
                    {
                        if (handRanks[o] != valTwoPairSecond && handRanks[o] != valTwoPairFirst) { valTwoPairSingle = handRanks[o]; }
                    }
                }
            }
            else if (handPairs.Count == 2)
            {
                hasOnePair = false;
                hasTwoPair = false;
                hasThreeOfAKind = false;
                hasFullHouse = false;
                hasFourOfAKind = false;

                //determine full house or four of a kind
                for (int i = 0; i < 2; i++)
                {
                    for (int j = i + 1; j < 3; j++)
                    {
                        for (int k = i + 2; k < 4; k++)
                        {
                            for (int l = i + 3; l < 5; l++)
                            {
                                if (handRanks[i] == handRanks[j] && handRanks[i] == handRanks[k] && handRanks[i] == handRanks[l])
                                {
                                    hasFourOfAKind = true;
                                    valFourOfAKindQuad = handRanks[i];
                                    for (int m = 0; m < 5; m++)
                                    {
                                        if (handRanks[m] != valFourOfAKindQuad) { valFourOfAKindSingle = handRanks[m]; }
                                    }
                                }
                            }
                        }
                    }
                }
                if (hasFourOfAKind == false)
                {
                    hasFullHouse = true;

                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = i + 1; j < 4; j++)
                        {
                            for (int k = i + 2; k < 5; k++)
                            {
                                if (handRanks[i] == handRanks[j] && handRanks[i] == handRanks[k])
                                {
                                    valFullHouseTriple = handRanks[i];
                                    for (int l = 0; l < 5; l++)
                                    {
                                        if (handRanks[l] != valFullHouseTriple) { valFullHouseDouble = handRanks[l]; }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ============================================
            // ============================================
            // creates an internal score for a targets hand
            // ============================================
            // ============================================

            //score the hand
            if (hasStraight == true && hasFlush == true)
            {
                //assign points for the hand
                valStraightFlush = valStraightFlush + (handRanks[4] * 16419454976);
                valStraightFlush = valStraightFlush + (handRanks[3] * 64138496);
                valStraightFlush = valStraightFlush + (handRanks[2] * 4008656);
                valStraightFlush = valStraightFlush + (handRanks[1] * 1002164);
                valStraightFlush = valStraightFlush + (handRanks[0] * 501082);
                handScore = valStraightFlush;

                //check for royal flush
                if (handRanks[4] == 14)
                {     
                    //record hand name
                    handName = "Royal Flush";
                }
                else
                {
                    //record hand name
                    handName = "Straight Flush";
                }
            }
            else if (hasFourOfAKind == true)
            {
                //assign points for the hand
                handScore = handScore + (valFourOfAKindQuad * 1470859210);
                handScore = handScore + valFourOfAKindSingle;

                //record hand name
                handName = "Four Of A Kind";
            }
            else if (hasFullHouse == true)
            {
                //assign points for the hand
                handScore = handScore + (valFullHouseTriple * 267690619);
                handScore = handScore + (valFullHouseDouble * 20148757);

                //record hand name
                handName = "Full House";
            }
            else if (hasStraight == false && hasFlush == true)
            {
                //assign points for the hand
                valFlush = valFlush + (handRanks[4] * 122880000);
                valFlush = valFlush + (handRanks[3] * 480000);
                valFlush = valFlush + (handRanks[2] * 30000);
                valFlush = valFlush + (handRanks[1] * 7500);
                valFlush = valFlush + (handRanks[0] * 3750);
                handScore = valFlush;

                //record hand name
                handName = "Flush";
            }
            else if (hasStraight == true && hasFlush == false)
            {
                //assign points for the hand
                valStraight = valStraight + (handRanks[4] * 14372411);
                valStraight = valStraight + (handRanks[3] * 14372411);
                valStraight = valStraight + (handRanks[2] * 14372411);
                valStraight = valStraight + (handRanks[1] * 14372411);
                valStraight = valStraight + (handRanks[0] * 14372411);
                handScore = valStraight;

                //record hand name
                handName = "Straight";
            }
            else if (hasThreeOfAKind == true)
            {
                //assign points for the hand
                handScore = handScore + (valThreeOfAKindTrip * 3 * 5133003);
                handScore = handScore + (valThreeOfAKindSingle1 + valThreeOfAKindSingle2);

                //record hand name
                handName = "Three Of A Kind";
            }
            else if (hasTwoPair == true)
            {
                //assign points for the hand
                handScore = handScore + (valTwoPairFirst * 2 * 1010123);
                handScore = handScore + (valTwoPairSecond * 2 * 96714);
                handScore = handScore + valTwoPairSingle;

                //record hand name
                handName = "Two Pair";
            }
            else if (hasOnePair == true)
            {
                //assign points for the hand
                handScore = handScore + (valOnePairPair * 2 * 230270);
                handScore = handScore + (valOnePairSingle1 + valOnePairSingle2 + valOnePairSingle3);

                //record hand name
                handName = "One Pair";
            }
            else if (hasHighCard == true)
            {
                //assign points for the hand
                valHighCard = valHighCard + (handRanks[4] * 65536);
                valHighCard = valHighCard + (handRanks[3] * 256);
                valHighCard = valHighCard + (handRanks[2] * 16);
                valHighCard = valHighCard + (handRanks[1] * 4);
                valHighCard = valHighCard + (handRanks[0] * 2);
                handScore = valHighCard;

                //record hand name
                handName = "High Card";
            }
            
            //record hand scores
            if (target == "player")
            {
                playerHandScore = handScore;
                playerHandName = handName;
                updatePlayerHandMessage();
            }
            if (target == "dealer")
            {
                dealerHandScore = handScore;
                dealerHandName = handName;
                //updateDealerHandMessage();
            }



            // ==============================
            // ==============================
            // determines the dealer discards
            // ==============================
            // ==============================

            //if the current game state is scoreinitialhands
            if (currentState == GameState.ScoreInitialHands)
            {
                //determine the dealers discard options
                if (target == "dealer")
                {
                    //dealer discard decision tools
                    int dealerHasClubs = 0;
                    int dealerHasDiamonds = 0;
                    int dealerHasHearts = 0;
                    int dealerHasSpades = 0;
                    int dealerHasTwo = 0;
                    int dealerHasThree = 0;
                    int dealerHasFour = 0;
                    int dealerHasFive = 0;
                    int dealerHasSix = 0;
                    int dealerHasSeven = 0;
                    int dealerHasEight = 0;
                    int dealerHasNine = 0;
                    int dealerHasTen = 0;
                    int dealerHasJack = 0;
                    int dealerHasQueen = 0;
                    int dealerHasKing = 0;
                    int dealerHasAce = 0;
                    bool determinedDiscards = false;

                    //extract data from dealers cards
                    for (int i = 0; i < 5; i++)
                    {
                        //count suits
                        if (dealerHand[i].Suit == XnaCards.Suit.Clubs) { dealerHasClubs = dealerHasClubs + 1; }
                        else if (dealerHand[i].Suit == XnaCards.Suit.Diamonds) { dealerHasDiamonds = dealerHasDiamonds + 1; }
                        else if (dealerHand[i].Suit == XnaCards.Suit.Hearts) { dealerHasHearts = dealerHasHearts + 1; }
                        else if (dealerHand[i].Suit == XnaCards.Suit.Spades) { dealerHasSpades = dealerHasSpades + 1; }

                        //count ranks
                        if (dealerHand[i].Rank == XnaCards.Rank.Two) { dealerHasTwo = dealerHasTwo + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Three) { dealerHasThree = dealerHasThree + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Four) { dealerHasFour = dealerHasFour + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Five) { dealerHasFive = dealerHasFive + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Six) { dealerHasSix = dealerHasSix + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Seven) { dealerHasSeven = dealerHasSeven + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Eight) { dealerHasEight = dealerHasEight + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Nine) { dealerHasNine = dealerHasNine + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Ten) { dealerHasTen = dealerHasTen + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Jack) { dealerHasJack = dealerHasJack + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Queen) { dealerHasQueen = dealerHasQueen + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.King) { dealerHasKing = dealerHasKing + 1; }
                        if (dealerHand[i].Rank == XnaCards.Rank.Ace) { dealerHasAce = dealerHasAce + 1; }

                        //count 4 card straights
                        for (int j = 0; j < 5; j++)
                        {
                            if (j != 0)
                            {
                                dealer4sd0.Add(GetCardRankValue(targetHand[j]));
                                dealer4sd0.Add(GetCardRankValue(targetHand[j]));
                            }
                            if (j != 1)
                            {
                                dealer4sd1.Add(GetCardRankValue(targetHand[j]));
                                dealer4sd1.Add(GetCardRankValue(targetHand[j]));
                            }
                            if (j != 2)
                            {
                                dealer4sd2.Add(GetCardRankValue(targetHand[j]));
                                dealer4sd2.Add(GetCardRankValue(targetHand[j]));
                            }
                            if (j != 3)
                            {
                                dealer4sd3.Add(GetCardRankValue(targetHand[j]));
                                dealer4sd3.Add(GetCardRankValue(targetHand[j]));
                            }
                            if (j != 4)
                            {
                                dealer4sd4.Add(GetCardRankValue(targetHand[j]));
                                dealer4sd4.Add(GetCardRankValue(targetHand[j]));
                            }
                        }
                        dealer4sd0.Sort();
                        dealer4sd1.Sort();
                        dealer4sd2.Sort();
                        dealer4sd3.Sort();
                        dealer4sd4.Sort();
                    }

                    //if the dealer does not need to discard
                    if (handName == "Royal Flush" || handName == "Straight Flush" || handName == "Full House" || handName == "Straight" || handName == "Flush") { determinedDiscards = true; }

                    //if the dealer is close to a flush, discard the odd suit
                    if (determinedDiscards == false)
                    {
                        if (dealerHasClubs == 4)
                        {
                            if (dealerHand[0].Suit != XnaCards.Suit.Clubs) { dealerDiscarding0 = true; determinedDiscards = true; }
                            if (dealerHand[1].Suit != XnaCards.Suit.Clubs) { dealerDiscarding1 = true; determinedDiscards = true; }
                            if (dealerHand[2].Suit != XnaCards.Suit.Clubs) { dealerDiscarding2 = true; determinedDiscards = true; }
                            if (dealerHand[3].Suit != XnaCards.Suit.Clubs) { dealerDiscarding3 = true; determinedDiscards = true; }
                            if (dealerHand[4].Suit != XnaCards.Suit.Clubs) { dealerDiscarding4 = true; determinedDiscards = true; }
                        }
                        else if (dealerHasDiamonds == 4)
                        {
                            if (dealerHand[0].Suit != XnaCards.Suit.Diamonds) { dealerDiscarding0 = true; determinedDiscards = true; }
                            if (dealerHand[1].Suit != XnaCards.Suit.Diamonds) { dealerDiscarding1 = true; determinedDiscards = true; }
                            if (dealerHand[2].Suit != XnaCards.Suit.Diamonds) { dealerDiscarding2 = true; determinedDiscards = true; }
                            if (dealerHand[3].Suit != XnaCards.Suit.Diamonds) { dealerDiscarding3 = true; determinedDiscards = true; }
                            if (dealerHand[4].Suit != XnaCards.Suit.Diamonds) { dealerDiscarding4 = true; determinedDiscards = true; }
                        }
                        else if (dealerHasHearts == 4)
                        {
                            if (dealerHand[0].Suit != XnaCards.Suit.Hearts) { dealerDiscarding0 = true; determinedDiscards = true; }
                            if (dealerHand[1].Suit != XnaCards.Suit.Hearts) { dealerDiscarding1 = true; determinedDiscards = true; }
                            if (dealerHand[2].Suit != XnaCards.Suit.Hearts) { dealerDiscarding2 = true; determinedDiscards = true; }
                            if (dealerHand[3].Suit != XnaCards.Suit.Hearts) { dealerDiscarding3 = true; determinedDiscards = true; }
                            if (dealerHand[4].Suit != XnaCards.Suit.Hearts) { dealerDiscarding4 = true; determinedDiscards = true; }
                        }
                        else if (dealerHasSpades == 4)
                        {
                            if (dealerHand[0].Suit != XnaCards.Suit.Spades) { dealerDiscarding0 = true; determinedDiscards = true; }
                            if (dealerHand[1].Suit != XnaCards.Suit.Spades) { dealerDiscarding1 = true; determinedDiscards = true; }
                            if (dealerHand[2].Suit != XnaCards.Suit.Spades) { dealerDiscarding2 = true; determinedDiscards = true; }
                            if (dealerHand[3].Suit != XnaCards.Suit.Spades) { dealerDiscarding3 = true; determinedDiscards = true; }
                            if (dealerHand[4].Suit != XnaCards.Suit.Spades) { dealerDiscarding4 = true; determinedDiscards = true; }
                        }
                    }

                    //else if the dealer is close to a straight
                    if (determinedDiscards == false)
                    {
                        if (dealer4sd0[0] - dealer4sd0[1] == 1 && dealer4sd0[1] - dealer4sd0[2] == 1 && dealer4sd0[2] - dealer4sd0[3] == 1) { dealerDiscarding0 = true; determinedDiscards = true; }
                        else if (dealer4sd1[0] - dealer4sd1[1] == 1 && dealer4sd1[1] - dealer4sd1[2] == 1 && dealer4sd1[2] - dealer4sd1[3] == 1) { dealerDiscarding1 = true; determinedDiscards = true; }
                        else if (dealer4sd2[0] - dealer4sd2[1] == 1 && dealer4sd2[1] - dealer4sd2[2] == 1 && dealer4sd2[2] - dealer4sd2[3] == 1) { dealerDiscarding2 = true; determinedDiscards = true; }
                        else if (dealer4sd3[0] - dealer4sd3[1] == 1 && dealer4sd3[1] - dealer4sd3[2] == 1 && dealer4sd3[2] - dealer4sd3[3] == 1) { dealerDiscarding3 = true; determinedDiscards = true; }
                        else if (dealer4sd4[0] - dealer4sd4[1] == 1 && dealer4sd4[1] - dealer4sd4[2] == 1 && dealer4sd4[2] - dealer4sd4[3] == 1) { dealerDiscarding4 = true; determinedDiscards = true; }
                    }

                    //else if the dealer has pairs
                    if (determinedDiscards == false)
                    {
                        dealerDiscarding0 = true;
                        dealerDiscarding1 = true;
                        dealerDiscarding2 = true;
                        dealerDiscarding3 = true;
                        dealerDiscarding4 = true;

                        if (dealerHasTwo > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Two) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Two) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Two) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Two) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Two) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasThree > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Three) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Three) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Three) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Three) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Three) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasFour > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Four) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Four) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Four) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Four) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Four) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasFive > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Five) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Five) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Five) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Five) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Five) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasSix > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Six) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Six) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Six) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Six) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Six) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasSeven > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Seven) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Seven) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Seven) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Seven) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Seven) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasEight > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Eight) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Eight) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Eight) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Eight) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Eight) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasNine > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Nine) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Nine) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Nine) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Nine) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Nine) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasTen > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Ten) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Ten) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Ten) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Ten) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Ten) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasJack > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Jack) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Jack) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Jack) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Jack) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Jack) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasQueen > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Queen) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Queen) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Queen) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Queen) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Queen) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasKing > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.King) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.King) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.King) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.King) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.King) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                        if (dealerHasAce > 1)
                        {
                            if (dealerHand[0].Rank == XnaCards.Rank.Ace) { dealerDiscarding0 = false; determinedDiscards = true; }
                            if (dealerHand[1].Rank == XnaCards.Rank.Ace) { dealerDiscarding1 = false; determinedDiscards = true; }
                            if (dealerHand[2].Rank == XnaCards.Rank.Ace) { dealerDiscarding2 = false; determinedDiscards = true; }
                            if (dealerHand[3].Rank == XnaCards.Rank.Ace) { dealerDiscarding3 = false; determinedDiscards = true; }
                            if (dealerHand[4].Rank == XnaCards.Rank.Ace) { dealerDiscarding4 = false; determinedDiscards = true; }
                        }
                    }

                    //else preserve top 2 cards
                    if (determinedDiscards == false)
                    {
                        dealerKeeping1 = handRanks[4];
                        dealerKeeping2 = handRanks[3];

                        if (GetCardRankValue(dealerHand[0]) == dealerKeeping1 || GetCardRankValue(dealerHand[0]) == dealerKeeping2) { dealerDiscarding0 = false; }
                        if (GetCardRankValue(dealerHand[1]) == dealerKeeping1 || GetCardRankValue(dealerHand[1]) == dealerKeeping2) { dealerDiscarding1 = false; }
                        if (GetCardRankValue(dealerHand[2]) == dealerKeeping1 || GetCardRankValue(dealerHand[2]) == dealerKeeping2) { dealerDiscarding2 = false; }
                        if (GetCardRankValue(dealerHand[3]) == dealerKeeping1 || GetCardRankValue(dealerHand[3]) == dealerKeeping2) { dealerDiscarding3 = false; }
                        if (GetCardRankValue(dealerHand[4]) == dealerKeeping1 || GetCardRankValue(dealerHand[4]) == dealerKeeping2) { dealerDiscarding4 = false; }
                    }
                }
            }
        }

        /// <summary>
        /// Gets the suit value for the given card
        /// </summary>
        /// <param name="card">the card</param>
        /// <returns>a value for the cards rank</returns>
        public int GetCardSuitValue(Card card)
        {
            switch (card.Suit)
            {
                case Suit.Clubs:
                    return 4;
                case Suit.Diamonds:
                    return 3;
                case Suit.Hearts:
                    return 2;
                case Suit.Spades:
                    return 1;
                default:
                    return 0;
            }
        }

        /// <summary>
        /// Gets the rank value for the given card
        /// </summary>
        /// <param name="card">the card</param>
        /// <returns>a value for the cards rank</returns>
        public int GetCardRankValue(Card card)
        {
            switch (card.Rank)
            {
                case Rank.Ace:
                    return 14;
                case Rank.King:
                    return 13;
                case Rank.Queen:
                    return 12;
                case Rank.Jack:
                    return 11;
                case Rank.Ten:
                    return 10;
                case Rank.Nine:
                    return 9;
                case Rank.Eight:
                    return 8;
                case Rank.Seven:
                    return 7;
                case Rank.Six:
                    return 6;
                case Rank.Five:
                    return 5;
                case Rank.Four:
                    return 4;
                case Rank.Three:
                    return 3;
                case Rank.Two:
                    return 2;
                default:
                    return 0;
            }
        }
        #endregion


    }
}
