﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FiveCardDraw
{
    /// <summary>
    /// An enumeration of the possible game states
    /// </summary>
    public enum GameState
    {
        InitialDeal,
        ScoreInitialHands,
        WaitingForPlayerToDiscard,
        DiscardPlayersCards,
        WaitingForDealerToDiscard,
        DiscardDealersCards,
        FinalDeal,
        ScoreFinalHands,
        DisplayHandResults,
        Exiting,
    }
}
